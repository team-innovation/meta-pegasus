#!/system/bin/sh
if ! applypatch -c MTD:recovery:5830656:01bc110a9d2accca44aeb4a96a6d3a021aa0be91; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:5830656:01bc110a9d2accca44aeb4a96a6d3a021aa0be91 MTD:recovery 01bc110a9d2accca44aeb4a96a6d3a021aa0be91 5830656 01bc110a9d2accca44aeb4a96a6d3a021aa0be91:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
