python3-brisa
=============

BRisa is a UPnP framework.
Comes from the work of Brisa Team back when maemo was shining... So all kudos and credits to them:  http://brisa.garage.maemo.org

I have just adapted this to python3 via method: http://docs.python.org/dev/howto/pyporting.html#during-installation . This porting has been done because I want a pyqt5 qml upnp control point to push media from any url to xbian ( http://www.xbian.org/ ) upnp media renderer.

So no warranty at all.



Packaging
--------------
Debian package with 
```sh
git-buildpackage
```
then install deb package...


Link to qml upnp av control point 
---------------
Soon to come
