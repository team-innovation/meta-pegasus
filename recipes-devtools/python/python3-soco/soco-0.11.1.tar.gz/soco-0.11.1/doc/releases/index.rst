
.. _releases:

SoCo releases
=============

.. toctree::
   :maxdepth: 1

   0.11.1
   0.11
   0.10
   0.9
   0.8
   0.7
   0.6
