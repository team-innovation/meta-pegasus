:orphan:

..
    This file is kept for backwards compatability, as there might be links to
    it. It just links to the new per-version overview that was added in
    https://github.com/SoCo/SoCo/pull/259

Release Notes
=============

The release notes have been split by version. See :ref:`releases` for an index.
