:orphan:

.. _tutorial_old_location:

Tutorial
========

The tutorial has been moved to :ref:`this location <getting_started>`.
