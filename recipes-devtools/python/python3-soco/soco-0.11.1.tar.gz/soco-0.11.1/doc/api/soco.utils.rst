soco.utils module
=================

.. automodule:: soco.utils
