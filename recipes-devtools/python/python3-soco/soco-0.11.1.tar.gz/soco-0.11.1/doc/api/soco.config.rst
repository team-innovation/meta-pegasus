soco.config module
==================

.. automodule:: soco.config
