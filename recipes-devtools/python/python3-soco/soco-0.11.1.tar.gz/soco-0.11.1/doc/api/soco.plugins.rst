soco.plugins package
====================

Submodules
----------

.. toctree::

   soco.plugins.example
   soco.plugins.spotify
   soco.plugins.wimp

Module contents
---------------

.. automodule:: soco.plugins
