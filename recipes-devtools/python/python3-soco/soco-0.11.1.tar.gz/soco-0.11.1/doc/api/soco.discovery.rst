soco.discovery module
=====================

.. automodule:: soco.discovery
