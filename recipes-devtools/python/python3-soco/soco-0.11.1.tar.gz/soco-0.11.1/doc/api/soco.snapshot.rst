soco.snapshot module
====================

.. automodule:: soco.snapshot
