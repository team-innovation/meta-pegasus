soco.core module
================

.. automodule:: soco.core
