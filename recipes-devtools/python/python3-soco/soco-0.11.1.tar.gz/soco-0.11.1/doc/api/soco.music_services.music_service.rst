soco.music_services.music_service module
========================================

.. automodule:: soco.music_services.music_service
