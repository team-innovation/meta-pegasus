soco.compat module
==================

.. automodule:: soco.compat
