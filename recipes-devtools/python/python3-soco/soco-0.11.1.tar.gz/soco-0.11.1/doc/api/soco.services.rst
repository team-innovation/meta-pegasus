soco.services module
====================

.. automodule:: soco.services
