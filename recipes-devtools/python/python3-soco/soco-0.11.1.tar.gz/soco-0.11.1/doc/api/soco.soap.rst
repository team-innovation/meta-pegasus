soco.soap module
================

.. automodule:: soco.soap
