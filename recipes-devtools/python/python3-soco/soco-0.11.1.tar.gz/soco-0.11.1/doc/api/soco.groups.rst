soco.groups module
==================

.. automodule:: soco.groups
