.. _module_reference:

soco package
============

Subpackages
-----------

.. toctree::

    soco.music_services
    soco.plugins

Submodules
----------

.. toctree::

   soco.alarms
   soco.cache
   soco.compat
   soco.config
   soco.core
   soco.data_structures
   soco.discovery
   soco.events
   soco.exceptions
   soco.groups
   soco.ms_data_structures
   soco.music_library
   soco.services
   soco.snapshot
   soco.soap
   soco.utils
   soco.xml
