soco.plugins.spotify module
===========================

.. automodule:: soco.plugins.spotify
