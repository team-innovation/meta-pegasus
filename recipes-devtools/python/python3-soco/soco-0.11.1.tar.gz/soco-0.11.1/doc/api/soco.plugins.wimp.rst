soco.plugins.wimp module
========================

.. automodule:: soco.plugins.wimp
