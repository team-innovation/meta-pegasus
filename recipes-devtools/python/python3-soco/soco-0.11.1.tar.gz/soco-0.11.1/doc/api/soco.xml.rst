soco.xml module
===============

.. automodule:: soco.xml
