soco.plugins.example module
===========================

.. automodule:: soco.plugins.example
