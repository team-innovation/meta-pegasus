soco.exceptions module
======================

.. automodule:: soco.exceptions
