soco.events module
==================

.. automodule:: soco.events
