Project Creator
===============
SoCo was created in 2012 at Music Hack Day Sydney by Rahim Sonawalla


Maintainers
===========

* Lawrence Akka
* Stefan Kögl
* Kenneth Nielsen


Contributors
============

(alphabetical)

* Petter Aas
* Murali Allada
* Joel Björkman
* Aaron Daubman
* Johan Elmerfjord
* David H
* Jeff Hinrichs
* Jeroen Idserda
* Todd Neal
* nixscripter
* Kenneth Nielsen
* Dave O'Connor
* Dennnis O'Reilly
* phut
* Dan Poirier
* Jason Ting
* Scott G Waters

